'use strict';
const http=require('node:http');const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const PORT=Number(process.env.PORT||3000);const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'_miesstapa_';const HTML_FILE=path.join(__dirname,'noel_clicker_partage.html');
const clients=new Map();let sharedEvent={active:false,multiplier:1,endsAt:0};
function send(res,status,obj){const body=JSON.stringify(obj);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});res.end(body)}
function safeEqual(a,b){const aa=Buffer.from(String(a));const bb=Buffer.from(String(b));return aa.length===bb.length&&crypto.timingSafeEqual(aa,bb)}
function writeEvent(res,name,data){try{res.write(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`);return true}catch{return false}}
function broadcast(name,data,filter=()=>true){let n=0;for(const [res,client] of clients){if(filter(client)&&writeEvent(res,name,data))n++}return n}
function playerList(){return [...new Map([...clients.values()].map(p=>[p.id,p])).values()].map(p=>({id:p.id,name:p.name||'Joueur'}))}
function publishPlayers(){const list=playerList();broadcast('players',list)}
function readBody(req,res,cb){let raw='';req.on('data',chunk=>{raw+=chunk;if(raw.length>12000){send(res,413,{error:'Requête trop volumineuse.'});req.destroy()}});req.on('end',()=>{let d;try{d=JSON.parse(raw||'{}')}catch{return send(res,400,{error:'JSON invalide.'})}cb(d)})}
const server=http.createServer((req,res)=>{
 if(req.method==='OPTIONS')return send(res,204,{});
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&url.pathname==='/events'){
  const id=String(url.searchParams.get('playerId')||'').slice(0,100);if(!id)return send(res,400,{error:'playerId manquant'});
  const client={id,name:String(url.searchParams.get('name')||'Joueur').slice(0,24)};
  res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type'});res.write(': Noël Clicker connecté\n\n');clients.set(res,client);
  writeEvent(res,'players',playerList());if(sharedEvent.active&&sharedEvent.endsAt>Date.now())writeEvent(res,'event',sharedEvent);
  const heartbeat=setInterval(()=>{try{res.write(': ping\n\n')}catch{}},20000);
  res.on('close',()=>{clearInterval(heartbeat);clients.delete(res);publishPlayers()});publishPlayers();return;
 }
 if(req.method==='POST'&&url.pathname.startsWith('/admin/'))return readBody(req,res,data=>{
  if(!safeEqual(data.password||'',ADMIN_PASSWORD))return send(res,403,{error:'Mot de passe Admin incorrect côté serveur.'});
  if(url.pathname==='/admin/verify')return send(res,200,{ok:true});
  if(url.pathname==='/admin/reward'){
   const amount=Number(data.amount),kind=data.kind==='flakes'?'flakes':'money',targetId=String(data.targetId||'all');if(!Number.isFinite(amount)||amount<0||amount>1e100)return send(res,400,{error:'Montant invalide.'});
   const payload={amount,kind,targetId};const delivered=broadcast('reward',payload,c=>targetId==='all'||c.id===targetId);return send(res,200,{ok:true,delivered,targetId});
  }
  if(url.pathname==='/admin/event'){
   const active=!!data.active;if(active){const multiplier=Number(data.multiplier),duration=Math.floor(Number(data.duration));if(![2,3,5,10,25,100].includes(multiplier)||!Number.isFinite(duration)||duration<1||duration>86400)return send(res,400,{error:'Multiplicateur ou durée invalide.'});sharedEvent={active:true,multiplier,endsAt:Date.now()+duration*1000}}else sharedEvent={active:false,multiplier:1,endsAt:0};
   const delivered=broadcast('event',sharedEvent);return send(res,200,{ok:true,delivered,...sharedEvent});
  }
  if(url.pathname==='/admin/announce'){
   const message=String(data.message||'').trim().slice(0,180);if(!message)return send(res,400,{error:'Message vide.'});const delivered=broadcast('announcement',{message,sentAt:Date.now(),durationMs:8000});return send(res,200,{ok:true,delivered});
  }
  return send(res,404,{error:'Route admin inconnue.'});
 });
 if(req.method==='GET'&&(url.pathname==='/'||url.pathname==='/index.html'))return fs.readFile(HTML_FILE,(err,content)=>{if(err)return send(res,500,{error:'Fichier HTML introuvable.'});res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(content)});
 if(req.method==='GET'&&url.pathname==='/health')return send(res,200,{ok:true,connectedPlayers:playerList().length,players:playerList()});
 res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('Page introuvable');
});
setInterval(()=>{if(sharedEvent.active&&sharedEvent.endsAt<=Date.now()){sharedEvent={active:false,multiplier:1,endsAt:0};broadcast('event',sharedEvent)}},1000);
server.listen(PORT,'0.0.0.0',()=>console.log(`Noël Clicker partagé sur le port ${PORT}; mot de passe Admin configuré.`));
